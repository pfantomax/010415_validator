#include "mainwindow.h"
#include "./ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    QRegularExpression regex("\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z|a-z]{2,}\\b");
    QValidator *validator = new QRegularExpressionValidator(regex, this);
    ui->emailLineEdit->setValidator(validator);

     connect(ui->validateButton, &QPushButton::clicked, this, &MainWindow::validateEmail);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::validateEmail()
{
    QString email = ui->emailLineEdit->text();

    if (ui->emailLineEdit->hasAcceptableInput()) {
        QMessageBox::information(this, "Valid Email", "email адреса валідна.");
    } else {
        QMessageBox::warning(this, "Invalid Email", "email адреса не валідна.");
    }
}

void MainWindow::on_validateEmail_clicked()
{

}

